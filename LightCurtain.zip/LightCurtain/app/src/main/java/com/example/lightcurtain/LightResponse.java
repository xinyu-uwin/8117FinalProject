package com.example.lightcurtain;

public class LightResponse {

    private String room_name;
    private String light_on;
    private String curtain_on;

    public String getRoom_name() {
        return room_name;
    }

    public void setRoom_name(String room_name) {
        this.room_name = room_name;
    }

    public String getLight_on() {
        return light_on;
    }

    public void setLight_on(String light_on) {
        this.light_on = light_on;
    }

    public String getCurtain_on() {
        return curtain_on;
    }

    public void setCurtain_on(String curtain_on) {
        this.curtain_on = curtain_on;
    }
}
