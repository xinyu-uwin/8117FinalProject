package com.example.lightcurtain;

import static com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.client.HttpClient.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.HttpRequest;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.HttpResponse;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.client.HttpClient;

import java.net.URI;
import java.net.URISyntaxException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private SeekBar lightSeekBar;
    private SeekBar curtainSeekbar;
    private TextView textView;
    int lightValue = 0;
    int curtainValue = 0;
    private String username = "vegesna00@gmail.com";    //this need to be assigned depending on who is logged in
    private String room_name = "bedroom-3";             //this need to be assigned depending on which room

    String Text = "light = "+lightValue+ " curtain = "+curtainValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);
        lightSeekBar = (SeekBar) findViewById(R.id.lightBar);
        curtainSeekbar = (SeekBar) findViewById(R.id.curtainBar);

        lightSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                lightValue = i;
                String Text = "light = "+lightValue+ " curtain = "+curtainValue;
                textView.setText(Text);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                updateLight(createRequest());
            }
        });

        curtainSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                curtainValue = i;
                String Text = "light = "+lightValue+ " curtain = "+curtainValue;
                textView.setText(Text);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                updateLight(createRequest());
            }
        });

    }
    public LightRequest createRequest(){        //request for light and curtains
        System.out.println("Light = "+ lightValue);
        LightRequest lightRequest = new LightRequest();
        lightRequest.setLight_on(lightValue);
        lightRequest.setCurtain_on(curtainValue);
        lightRequest.setUsername(username);
        lightRequest.setRoom_name(room_name);

        return lightRequest;
    }

    public void updateLight(LightRequest lightRequest){
        Call<LightResponse> lightResponseCall = ApiClient.getUserService().saveUsers(lightRequest);
        lightResponseCall.enqueue(new Callback<LightResponse>() {
            @Override
            public void onResponse(Call<LightResponse> call, Response<LightResponse> response) {
                if(response.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Updated Sucessfully", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this, "Request Failed", Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onFailure(Call<LightResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Request Failed"+t.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}