package com.example.lightcurtain;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface UserService {
    @POST("user/device/control")
    Call<LightResponse> saveUsers(@Body LightRequest lightRequest);
}
